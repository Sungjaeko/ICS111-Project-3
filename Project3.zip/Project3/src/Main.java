import java.util.*;
public class Main {
	static int screenSizeX = 512;
	static int screenSizeY = 512;

	public static void main(String[] args) {
		int clickX = EZ.getWindowWidth()/2; // Assigns clickX and clickY to center of screen
		int clickY = EZ.getWindowHeight()/2;
		EZ.initialize(screenSizeX, screenSizeY);
		
		
		ArrayList<Bullet> bulletList = new ArrayList<Bullet>();
		
		while (true)
		{
			if (EZInteraction.wasMouseLeftButtonPressed()) {
				  clickX = EZInteraction.getXMouse(); 
				  clickY = EZInteraction.getYMouse();
				  Bullet aBullet = new Bullet(screenSizeX/2, screenSizeY/2);
				  bulletList.add(aBullet);
				  for(int i =0; i < bulletList.size(); i++)
				  {

						Bullet eachBullet;
						eachBullet = bulletList.get(i);
						eachBullet.shoot();
				  }
			}
			
		/*	 if (myBug.getX() > clickX) {
	        	  myBug.moveLeft(10);
	          }
	          if (myBug.getX() < clickX) {
	        	  myBug.moveRight(10);
	          }
	          if (myBug.getY() > clickY){
	        	  myBug.moveUp(10);
	          }
	          
	          if (myBug.getY() < clickY){
	        	  myBug.moveDown(10);
	          }
	          */
		      
		      EZ.refreshScreen();
		}
	}

}

import java.awt.event.KeyEvent;
import java.util.*;
public class Bullet {
	
	static int x;
	static int y;
	static EZImage picture;
	static int speed;
	
	public Bullet(int posx, int posy)
	{
		posx = x;
		posy = y;
		//picture = EZ.addImage("Bullet1.png", x, y);
	}
	
	public void shoot()
	{
		picture.moveForward(10);
	}
	
	
	protected void finalize() {		// finalize is a special function designed to destroy your object (destructor)
		EZ.removeEZElement(picture);		// Destroy the picture of the bubble
	}
	
}
